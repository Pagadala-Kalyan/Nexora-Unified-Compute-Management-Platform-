export default { plugins: {} }
